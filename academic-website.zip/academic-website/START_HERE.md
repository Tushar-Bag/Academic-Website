# Start Here — Project Status & How to Work With Claude on This Site

**What this file is for:** if you're starting a brand-new chat with Claude
about this website, upload this file first (or paste the relevant section)
and say what you want done. It tells Claude everything about the project's
current state, how you like to work, and exactly where to make common
edits — so Claude doesn't need to re-explore the whole codebase from
scratch or ask you questions it can already answer from here.

---

## 1. What this project is

A personal academic website for **Tushar Bag**, Assistant Professor of
Mathematics, SRM University AP (algebraic coding theory / quantum
error-correcting codes). Plain HTML/CSS/JS, no framework, no build step.
Hosted for free on **GitHub Pages**. LaTeX in publication titles renders
via a self-hosted copy of MathJax (no internet dependency).

- **GitHub repo:** https://github.com/Tushar-Bag/Academic-Website
- **Live site:** https://tushar-bag.github.io/Academic-Website/
- **Repo visibility:** Public (was private during development; made public
  so GitHub Pages could serve it on the free plan).
- **Search-engine indexing:** ON. The `noindex` privacy switch has been
  removed from every page except `404.html` (which should always stay
  noindex — that's normal practice, not a leftover privacy setting).
  `robots.txt` allows all crawlers.

## 2. How updates get made — the workflow

The user does **not** have GitHub Desktop installed (limited disk space)
and edits everything through **github.com in the browser**. There are two
patterns Claude should use when handing back edited files:

- **One file changed →** tell the user to open that file on GitHub, click
  the pencil icon (top-right of the code view), select all (Cmd+A),
  delete, paste the new content, scroll down, write a commit message,
  click **"Commit changes."** Always select **"Commit directly to the
  main branch"** (not the pull-request option) when GitHub asks.
- **Several files changed →** tell the user to download the full project
  zip, unzip it, then on GitHub click **Add file → Upload files**, and
  drag either the individual changed files or the whole unzipped folder
  into the upload box (GitHub will overwrite files with matching names/paths).
  Same commit-directly-to-main step at the end.

After committing, GitHub Pages rebuilds automatically within 1–2 minutes.
To verify a change went live: visit the page and **hard-refresh**
(Cmd+Option+R on Safari, Cmd+Shift+R on Chrome) since browsers cache
aggressively. The **Actions** tab on GitHub shows build/deploy status if
something isn't showing up.

**Editing conventions Claude should keep following:**
- Never actually delete content the user asks to remove from the page —
  wrap it in an HTML comment instead (`<!-- HIDDEN FOR NOW: ... -->` with
  a note on how to restore it), so it can come back with one edit later.
- **Watch for nested comments.** If the explanatory note inside a hidden
  block itself contains the literal text `-->`, it closes the comment
  early and dumps raw text onto the live page. This happened once in this
  project (teaching.html) — always grep/search the file for stray `-->`
  after adding a HIDDEN block, and ideally verify with Python's
  `html.parser` that the file still parses as valid HTML before sending
  it back.
- Match the existing CSS classes rather than inventing new ad-hoc styles:
  `.prose` for paragraphs, `.bullet-list` for bulleted content (added
  partway through this project, styled with navy bullet markers),
  `.notice` for boxed callouts, `.pub-item`/`.pub-key` for publication
  entries, `.news-list` for the News section, `.person` for student
  entries.

## 3. Full file structure

```
academic-website/
├── index.html          Home: profile, About, News, hidden Selected Publications section
├── research.html        Research interests (bulleted list) + hidden topic-block sections
├── publications.html    Preprints, Journal Papers, hidden Conference Papers section
├── teaching.html        Courses table, hidden Course Materials section
├── students.html        Open Positions (live, in nav) + hidden Current/Former Students
├── 404.html
├── robots.txt            Currently allows all crawlers (site is public/indexed)
├── css/style.css         All styling — design tokens at top, .bullet-list added later
├── js/main.js            Mobile nav + scroll animation
├── js/mathjax/           Self-hosted LaTeX renderer — never edit
├── files/cv.pdf           Downloadable CV (real, compiled from the user's LaTeX CV)
├── images/profile.jpg    Was a placeholder "TB" monogram; user is in the process of
│                         replacing it with a real photo (check current state — see §5)
├── README.md             Original file-by-file documentation
├── MANUAL.md             Full beginner's manual (GitHub Pages setup, privacy, etc.)
└── CONTENT_UPDATE_GUIDE.md   Quick lookup: task → file → exact template to paste
```

`CONTENT_UPDATE_GUIDE.md` (already in the repo) has copy-paste templates
for the recurring tasks — adding a journal paper, preprint, news item,
course, student, etc. Read it before making that kind of edit; don't
recreate those templates from scratch.

## 4. Navigation (current, as of last handoff)

Every page's nav bar: **Home | Research | Publications | Teaching | Open
Positions**. The "Open Positions" link (→ `students.html`) is live and
un-hidden on all 5 pages (it used to be commented out as "Students &
Positions" — that changed).

## 5. Current state of each page — what's shown vs. hidden

**index.html (Home)**
- Profile photo, contact links (email, personal email, Google Scholar,
  ResearchGate), office = "Admin Block, 4th Floor, Cubicle No. 48".
- About text: PhD from IIT Patna (no year), M.Sc. from IIT Kanpur.
- "Download CV" / "View publications" buttons: **hidden** (commented out).
- News list, newest first: (1) QuTI faculty announcement with a link to
  srmap.edu.in/quti/, (2) PhD/postdoc recruiting note, (3) "Joined SRM
  University AP" (no "Grade I" — removed everywhere it appeared). The
  2025 paper-accepted item and 2023-07 postdoc-fellowship item are
  **hidden**.
- "Selected Publications" section: **hidden** entirely.
- Hidden Biography section still exists lower in the file (search
  `BIOGRAPHY-SWITCH`), also has "Grade I" and the PhD year removed for
  consistency, still has an `[EDIT-PLACEHOLDER]` for personal details.
- **Photo status: check this.** As of the last message in this
  conversation, the user was in the process of uploading their real
  photo to replace the placeholder — confirm with them whether
  `images/profile.jpg` is now their actual photo or still the "TB"
  placeholder before assuming either way.

**research.html**
- Intro content is now a **bulleted list** (`.bullet-list`), not
  paragraphs — 4 bullets covering: structural coding theory focus,
  current record-breaking quantum codes work, DNA codes/cryptography
  applications, and openness to finite/algebraic geometry & topological
  codes collaboration.
- "Algebraic Coding Theory" and "Quantum Error-Correcting Codes" topic
  blocks: **hidden**.
- "Collaborators" section: **hidden**.
- Keyword pills row still visible under the bullet list.

**publications.html**
- Preprints [P2] and [P1]: badges ("revision submitted") removed, arXiv
  links added — [P2] "Some new non-binary quantum codes from
  one-generator quasi-cyclic codes" → arxiv.org/abs/2412.13613; [P1]
  "Quantum Codes from Group Codes" (title corrected to match the actual
  arXiv paper) → arxiv.org/abs/2412.13616.
- All 25 journal papers [J25]→[J1]: unchanged, full list live.
- "Conference Papers" section: hidden (was already hidden from the
  original build, never activated).

**teaching.html**
- Courses table, newest first: FIC 103 (Odd Sem. 2026), QIC 150 "Linear
  Algebra and Group Theory" (Odd Sem. 2026), FIC 117, FIC 103 (Odd Sem.
  2025), MATH 1007, MATH 1107 — all SRM AP / Carleton.
- MA 201, MA 427 (IIT Patna TA rows) and the "Earlier: DPS Bhagalpur"
  line: **hidden**. Intro paragraph updated to only mention SRM AP and
  Carleton (no IIT Patna TA / high-school mention).
- "Course Materials" section: **hidden**.

**students.html (Open Positions)**
- Page title/heading: "Open Positions" (no longer "Students & Open
  Positions" — simplified since the redundant intro was also cleaned up).
- Main content: a fully rewritten, detailed Open Positions section
  covering PhD Opportunities (core requirements + "beyond that" areas
  phrased as things the user is happy to see students learn or already
  know, not a hard requirement list), Postdoctoral Opportunities, How to
  Apply (separate lists for PhD vs. postdoc applicants), and a "PhD
  Admission Information" box linking to
  srmap.edu.in/research/phd-admissions/.
- "Current Students" and "Former Students" sections: **hidden** (no
  students yet).

## 6. Known pending placeholders

Still unfilled, last checked: office number was filled in (done), but
ORCID/GitHub/LinkedIn links, the hidden Biography section's personal
details, and lecture-note PDF links (teaching.html Course Materials,
itself currently hidden) remain placeholders. Ask before assuming any of
these have been filled unless the user states otherwise.

## 7. What NOT to do

- Don't touch `js/mathjax/` — self-hosted library, not hand-written content.
- Don't rename `cv.pdf` or `profile.jpg` — other files reference those
  exact filenames.
- Don't re-add the `noindex` meta tag or lock down `robots.txt` again
  unless the user explicitly asks to go back to private/unlisted mode —
  the site is intentionally public and indexable now.
- Don't suggest GitHub Desktop or CLI git commands as the primary
  workflow — the user works entirely through github.com in the browser
  (see §2). Desktop app was ruled out due to limited disk space.

## 8. User's working preferences (apply throughout)

- Don't run long code/commands directly without reason; keep the
  container/bash usage to short necessary checks (validating HTML,
  simulating comment-stripping, etc.) rather than anything heavy.
- Give instructions as clear step-by-step turns, explicitly split between
  "you do this" and "I'll do this" — especially for anything on GitHub's
  website, since the user is not a developer and appreciates precise,
  numbered steps rather than general summaries.
- When several files change at once, always regenerate and re-share the
  full project zip alongside the individual changed files, so the user
  always has the option of either single-file or bulk-upload workflows.
